ops
===

The operations collection consists of various default gates and is a work-in-progress, as users start to work with ProjectQ.

Module contents
---------------

.. automodule:: projectq.ops
    :members:
    :special-members: __init__,__or__
    :imported-members:
