libs
====

The library collection of ProjectQ which, for now, only consists of a tiny math library. Soon, more libraries will be added.

Subpackages
-----------

.. toctree::

    projectq.libs.math

Module contents
---------------

.. automodule:: projectq.libs
    :members:
    :special-members: __init__
    :imported-members:
